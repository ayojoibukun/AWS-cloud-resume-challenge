import json
import boto3

dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
table = dynamodb.Table('MyResumeViewCount')

def lambda_handler(event, context):
    response = table.update_item(
        Key={'id': 'views'},  # must match your table schema
        UpdateExpression="SET current_views = if_not_exists(current_views, :start) + :inc", #set current views and adds increment
        ExpressionAttributeValues={
            ':start': 0,
            ':inc': 1
        },
        ReturnValues="UPDATED_NEW"
    )
    
    new_views = response['Attributes']['current_views']
    
    return {
        'statusCode': 200,
        'body': json.dumps({"views": int(new_views)})
    }
